Notes

- contact sphere radius 10, deformed sphere radius 31.203
- gravity used to make big deformable sphere drop on small rigid sphere, while shifting rigid sphere twice to alter input load
- issue: a 'contact deformation' is more likely a moving object onto a non-moving deformable one -- in this case the deformable ball can move past the rigid one
- issue: contact point and contact point displacement cannot be directly inferred using (correspondences+euclidean distance) for offcenter samples